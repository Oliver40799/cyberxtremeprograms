let cartCount = 0;

function addToCart() {
  cartCount++;
  alert("Producto agregado al carrito ✅ Total: " + cartCount);
}
