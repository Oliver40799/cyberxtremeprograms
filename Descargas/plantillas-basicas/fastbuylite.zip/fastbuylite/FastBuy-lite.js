function buyProduct(productName) {
  const notification = document.getElementById("notification");
  notification.textContent = productName + " agregado (ejemplo)";
  notification.classList.remove("hidden");

  setTimeout(() => {
    notification.classList.add("hidden");
  }, 2000);
}
