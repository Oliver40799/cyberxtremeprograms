document.querySelector("form").addEventListener("submit", (e) => {
  e.preventDefault();
  alert("Mensaje enviado (demo).");
});

function comprar(producto) {
  alert(producto + " agregado (demo).");
}
