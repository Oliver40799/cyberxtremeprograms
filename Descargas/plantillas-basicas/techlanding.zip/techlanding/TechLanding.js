// TechLanding no necesita funciones JS avanzadas.
// Podés agregar validaciones de formulario si querés.
console.log("TechLanding cargado correctamente ✅");
