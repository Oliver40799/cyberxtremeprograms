let cartCount = 0;

function addToCart() {
  cartCount++;
  document.getElementById("cart-count").textContent = cartCount;
}

document.getElementById("search").addEventListener("keyup", function() {
  let filter = this.value.toLowerCase();
  let products = document.querySelectorAll(".product");

  products.forEach(product => {
    let name = product.querySelector("h3").textContent.toLowerCase();
    if (name.includes(filter)) {
      product.style.display = "";
    } else {
      product.style.display = "none";
    }
  });
});
